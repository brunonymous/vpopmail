#include <stdio.h>
#include "popfetch.h"

int main(int argc, char *argv[])
{
  int ret = 0;

  ret = pop_init();
  if (!ret)
     return 0;
  
  while(1) {
    ret = pop_loop();
    if (!ret)
       break;
  }
 
  return 0;
}
