<HTML>
<HEAD>
<TITLE>Mail Server Online Logging</TITLE>
</HEAD>
<BODY>
<TABLE WIDTH='100%'>
<TR>
<TD ALIGN='center'>
<FONT SIZE='+2'>POP3 Logs</FONT>
</TD>
</TR>
<TR>
<TD>
<TABLE>
<TR>
<TD VALIGN='top'>
<TABLE BORDER='1'>
<?php
if (!(isset($Page))){ $Page = 1; }
include ("./global.php");
$Offset = ($Page - 1) * $Limit;
$DBLink = mysql_connect("$DB_HOST", "$DB_USER", "$DB_PASS")
 or die ("Cannot connect to database server.");
mysql_select_db("$DB_NAME", $DBLink)
 or die ("Cannot open database.");
if ($Action == 'index' or $RemoveSuccessful == 1){
 $DQuery = "delete from $TABLE_VLOG where error='2'";
 $DResult = mysql_query($DQuery, $DBLink)
  or die("Cannot query database.");
}
if ($Action == 'Delete'){
 $DQuery = "DELETE FROM $TABLE_VLOG
             WHERE timestamp='$UNIXTime'
               AND user='$user'
               AND domain='$domain'";
 $DResult = mysql_query($DQuery, $DBLink)
  or die("Cannot query database.");
}
$SQuery = "SELECT COUNT(*) AS TOTAL FROM $TABLE_VLOG";
$SResult = mysql_query($SQuery, $DBLink)
 or die("Cannot query database.");
$SRow = mysql_fetch_object($SResult);
$TOTAL = $SRow->TOTAL;
print "<TR><TH ALIGN='left' NOWRAP>
       <A HREF='./pop3.php'>Total items in log:</A></TH>
       <TD ALIGN='right'>$TOTAL</TD></TR>";
$SQuery = "SELECT COUNT(*) AS TOTAL FROM $TABLE_VLOG
            WHERE error='1'";
$SResult = mysql_query($SQuery, $DBLink)
 or die("Cannot query database.");
$SRow = mysql_fetch_object($SResult);
$TOTAL1 = $SRow->TOTAL;
print "<TR><TH ALIGN='left' NOWRAP>
       <A HREF='./pop3.php?ErrorCode=1'>user not found:</A></TH>
       <TD ALIGN='right'>$TOTAL1</TD></TR>";
$SQuery = "SELECT COUNT(*) AS TOTAL FROM $TABLE_VLOG
            WHERE error='3'";
$SResult = mysql_query($SQuery, $DBLink)
 or die("Cannot query database.");
$SRow = mysql_fetch_object($SResult);
$TOTAL3 = $SRow->TOTAL;
print "<TR><TH ALIGN='left' NOWRAP>
       <A HREF='./pop3.php?ErrorCode=3'>password fail:</A></TH>
       <TD ALIGN='right'>$TOTAL3</TD></TR>";
// errors
// 1 = User not found
// 2 = Successful
// 3 = Bad Password
// id, user, passwd, domain, logon, remoteip, message, timestamp, error 
if ($ErrorCode == 0){ $LastPage = ceil ($TOTAL / $Limit); $ErrorCode = '%'; }
elseif ($ErrorCode == 1){ $LastPage = ceil($TOTAL1 / $Limit); }
elseif ($ErrorCode == 2){ $LastPage = ceil ($TOTAL2 / $Limit); }
elseif ($ErrorCode == 3){ $LastPage = ceil ($TOTAL3 / $Limit); }
else { $LastPage = ceil ($TOTAL / $Limit); $ErrorCode = '%'; }
?>
<TR><TD>&#160;</TD><TD>&#160;</TD></TR>
<TR><TH><A HREF='./index.php'>Home</A></TH><TD>&#160;</TD></TR>
<?php
if ($RemoveSuccessful == 0){
 print "<TR><TH ALIGN='left'><A HREF='./pop3.php?Action=index'>Remove Successful</A></TH><TD>&#160;</TD></TR>";
}
?>
</TABLE>
</TD>
<TD WIDTH='15'>&#160;</TD>
<TD VALIGN='top'>
<?php
if ($TOTAL > 0){
?>
<TABLE BORDER='1' CELLPADDING='0' CELLSPACING='0'>
<TR>
<TH>DELETE</TH>
<TH>DATE/TIME</TH>
<TH>USER</TH>
<TH>DOMAIN</TH>
<TH>PASSWORD</TH>
<TH>ERROR</TH>
</TR>
<?php
$SQuery = "SELECT FROM_UNIXTIME(timestamp) AS timestamp,
             timestamp AS UNIXTime,
             user, domain, passwd, error
             FROM $TABLE_VLOG
            WHERE error LIKE '$ErrorCode'
            ORDER BY timestamp DESC
            LIMIT $Offset, $Limit";
$SResult = mysql_query($SQuery, $DBLink)
 or die("Cannot query database.");
while ($SRow = mysql_fetch_object($SResult)){
 $timestamp = $SRow->timestamp;
 $UNIXTime = $SRow->UNIXTime;
 $user = $SRow->user;
 $domain = $SRow->domain;
 if ($domain == ''){ $pdomain = 'UNDEFINED'; }
 else { $pdomain = $domain; }
 $passwd = $SRow->passwd;
 if ($passwd == ''){ $passwd = 'UNDEFINED'; }
 $error = $SRow->error;
 if ($error == 1) { $error = "User Not Found"; }
 elseif ($error == 2) { $error = "Successful"; }
 elseif ($error == 3) { $error = "Password Failure"; }
 print "<TR VALIGN='middle'><FORM ACTION='' METHOD='post'>
            <INPUT NAME='UNIXTime' TYPE='hidden' VALUE='$UNIXTime'>
            <INPUT NAME='user' TYPE='hidden' VALUE='$user'>
            <INPUT NAME='domain' TYPE='hidden' VALUE='$domain'>
        <TD ALIGN='center'><BR><INPUT NAME='Action' TYPE='submit' VALUE='Delete'></FORM></TD>
        <TD>&#160;$timestamp&#160;</TD>
        <TD>&#160;$user&#160;</TD>
        <TD>&#160;$pdomain&#160;</TD>
        <TD>&#160;$passwd&#160;</TD>
        <TD>&#160;$error&#160;</TD></TR>";
}
?>
</TABLE>
<BR>
<?php
 if ($Page > 1){
  $PPage = $Page - 1;
  print "<A HREF='./pop3.php?ErrorCode=$ErrorCode&Page=1'>First Page</A> &#160; ";
  print "<A HREF='./pop3.php?ErrorCode=$ErrorCode&Page=$PPage'>Previous Page</A> &#160;";
 }
 if ($Page < $LastPage){
  $NPage = $Page + 1;
  print "<A HREF='./pop3.php?ErrorCode=$ErrorCode&Page=$NPage'>Next Page</A> &#160;";
  print "<A HREF='./pop3.php?ErrorCode=$ErrorCode&Page=$LastPage'>Last Page</A>";
 }
}
?>
</TD>
</TR>
<?php
mysql_close($DBLink);
?>
</TABLE>
</TD>
</TR>
</TABLE>
<BR>
<?php include ("./license.php"); ?>
</BODY>
</HTML>
