<HR>Written and Freely Distributed by Sequential Logic.
<BR>Version <?php print $Version; ?>
