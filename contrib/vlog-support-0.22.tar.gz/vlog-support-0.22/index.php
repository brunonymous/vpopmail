<?php include ("./global.php"); ?>
<HTML>
<HEAD>
<TITLE>Mail Server Online Logging</TITLE>
</HEAD>
<BODY>
<A HREF='./smtp-relay.php'>POP Before SMTP Relaying IPs</A>
<BR>
<A HREF='./pop3.php'>POP3 Logs</A>
<BR>
<A HREF='./lastauth.php'>POP3 Last Authentication</A>
<?php include ("./license.php"); ?>
</BODY>
</HTML>
