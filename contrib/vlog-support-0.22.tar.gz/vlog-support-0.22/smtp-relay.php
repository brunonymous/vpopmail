<HTML>
<HEAD>
<TITLE>Mail Server Online Logging</TITLE>
</HEAD>
<BODY>
<TABLE WIDTH='100%'>
<TR>
<TD ALIGN='center'>
<FONT SIZE='+2'>POP Before SMTP Relaying IPs</FONT>
</TD>
</TR>
<TR>
<TD>
<TABLE>
<TR>
<TD VALIGN='top'>
<TABLE BORDER='1'>
<?php
if (!(isset($Page))){ $Page = 1; }
include ("./global.php");
$Offset = ($Page - 1) * $Limit;
$DBLink = mysql_connect("$DB_HOST", "$DB_USER", "$DB_PASS")
 or die ("Cannot connect to database server.");
mysql_select_db("$DB_NAME", $DBLink)
 or die ("Cannot open database.");
if ($Action == 'Delete'){
 $DQuery = "DELETE FROM $TABLE_RELAY
             WHERE timestamp='$UNIXTime'
               AND ip_addr='$IPAddress'";
 $DResult = mysql_query($DQuery, $DBLink)
  or die("Cannot query database.");
}
$SQuery = "SELECT COUNT(*) AS TOTAL FROM $TABLE_RELAY";
$SResult = mysql_query($SQuery, $DBLink)
 or die("Cannot query database.");
$SRow = mysql_fetch_object($SResult);
$TOTAL = $SRow->TOTAL;
print "<TR><TH ALIGN='left' NOWRAP>
       <A HREF='./smtp-relay.php'>Total items in log:</A></TH>
       <TD ALIGN='right'>$TOTAL</TD></TR>";
$LastPage = ceil ($TOTAL / $Limit);
?>
<TR><TD>&#160;</TD><TD>&#160;</TD></TR>
<TR><TH><A HREF='./index.php'>Home</A></TH><TD>&#160;</TD></TR>
</TABLE>
</TD>
<TD WIDTH='15'>&#160;</TD>
<TD VALIGN='top'>
<?php
if ($TOTAL > 0){
?>
<TABLE BORDER='1' CELLPADDING='0' CELLSPACING='0'>
<TR>
<TH>DELETE</TH>
<TH>DATE/TIME OPENED</TH>
<TH>REMOTE IP ADDRESS</TH>
<TH>OPENED BY</TH>
</TR>
<?php
$SQuery = "SELECT FROM_UNIXTIME(timestamp) AS timestamp,
             timestamp AS UNIXTime, ip_addr
             FROM $TABLE_RELAY
            ORDER BY timestamp DESC
            LIMIT $Offset, $Limit";
$SResult = mysql_query($SQuery, $DBLink)
 or die("Cannot query database.");
while ($SRow = mysql_fetch_object($SResult)){
 $timestamp = $SRow->timestamp;
 $UNIXTime = $SRow->UNIXTime;
 $ip_addr = $SRow->ip_addr;
 print "<TR VALIGN='middle'><FORM ACTION='' METHOD='post'>
            <INPUT NAME='UNIXTime' TYPE='hidden' VALUE='$UNIXTime'>
            <INPUT NAME='IPAddress' TYPE='hidden' VALUE='$ip_addr'>
        <TD ALIGN='center'><BR><INPUT NAME='Action' TYPE='submit' VALUE='Delete'></FORM></TD>
        <TD>&#160;$timestamp&#160;</TD>
        <TD>&#160;$ip_addr&#160;</TD>
        <TD>";
 $SQuery = "SELECT CONCAT(user,'@',domain) AS email
              FROM $TABLE_LASTAUTH
             WHERE remote_ip='$ip_addr'
             ORDER BY domain, user DESC";
 $SResult2 = mysql_query($SQuery, $DBLink)
  or die("Cannot query database.");
 if (mysql_num_rows($SResult2) > 0){
  while ($SRow2 = mysql_fetch_object($SResult2)){
   $email = $SRow2->email; 
   print "&#160;$email&#160;<BR>";
  }
 }
 else {
  print "&#160;$email&#160;";
 }
 print "</TD></TR>";
}
?>
</TABLE>
<BR>
<?php
 if ($Page > 1){
  $PPage = $Page - 1;
  print "<A HREF='./smtp-relay.php?Page=1'>First Page</A> &#160; ";
  print "<A HREF='./smtp-relay.php?Page=$PPage'>Previous Page</A> &#160;";
 }
 if ($Page < $LastPage){
  $NPage = $Page + 1;
  print "<A HREF='./smtp-relay.php?Page=$NPage'>Next Page</A> &#160;";
  print "<A HREF='./smtp-relay.php?Page=$LastPage'>Last Page</A>";
 }
}
?>
</TD>
</TR>
<?php
mysql_close($DBLink);
?>
</TABLE>
</TD>
</TR>
</TABLE>
<BR>
<?php include ("./license.php"); ?>
</BODY>
</HTML>
