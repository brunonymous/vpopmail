<?php
$Limit = 10;
$TABLE_LASTAUTH = "lastauth";
$TABLE_RELAY = "relay";
$TABLE_VLOG = "vlog";
$DB_USER = "vpopmail";
$DB_PASS = "password";
$DB_HOST = "localhost";
$DB_NAME = "vpopmail";
// Remove Successful by default (1 = Yes, Anything Else = No)
$RemoveSuccessful = 0;
$Version = "0.22";
?>
